package com.laetienda.frontend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontendApplicationTests {

	@Test
	void contextLoads() {
	}

}
